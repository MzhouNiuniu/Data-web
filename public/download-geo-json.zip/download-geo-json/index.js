const https = require('https')
const fs = require('fs')
const path = require('path')

/**
 * 使用阿里api
 */
function getBlockDetailApi(code) {
    return `https://geo.datav.aliyun.com/areas/bound/${code}.json`
}

function getBlockChildrenlApi(code) {
    return `https://geo.datav.aliyun.com/areas/bound/${code}_full.json`
}

function getStoragePath(p) {
    return path.join(__dirname, './data', p)
}

function autoDownload(code, name, done = false) {

    console.log(name, '-', code)
    // 获取区块详情
    https.get(getBlockDetailApi(code), req => {
        let data = ''
        req.on('data', chunk => data += chunk)
        req.on('end', () => {
            fs.writeFile(getStoragePath(code + '.json'), data, function (err) {
                if (err) {
                    console.log(`${code} download failed`)
                }
            })
        })
    })

    // 获取区块子地区列表
    if (done) {
        return
    }
    https.get(getBlockChildrenlApi(code), req => {
        let data = ''
        req.on('data', chunk => data += chunk)
        req.on('end', () => {
            fs.writeFile(getStoragePath(code + '_full.json'), data, function (err) {
                if (err) {
                    console.log(`${code}_full download failed`)
                }
            })

            data = JSON.parse(data)
            setTimeout(() => {
                data.features.forEach((item,index) => {
                    const { properties } = item
                    if (properties.adcode === 100000 || properties.adcode === code) return // fix 获取中国数据时包含自身
                    // if (properties.childrenNum === 0) return
                    setTimeout(function () {
                        autoDownload(properties.adcode, properties.name, properties.childrenNum === 0)
                    }, 500 * index)
                })
            }, 1000)
        })
    })
}

if (!fs.existsSync(path.join(__dirname, './data'))) {
    fs.mkdirSync(path.join(__dirname, './data'))
}

// 默认从中国开始爬取
autoDownload(100000, '中华人民共和国')
